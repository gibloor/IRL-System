"use client"

import React from 'react'

const Authorize = () => {

  return (
    <div>

    </div>
  )
}

export default Authorize