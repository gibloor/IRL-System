"use client"

import NotificationTemplate from '@/components/Notifications/NotificationTemplate'
import React, { useState } from 'react'

import styles from './styles.module.css'

const CreateCharacter = () => {
  const [isActive, setIsActive] = useState(1);

  return (
    <div>
      <NotificationTemplate
        type='create-character'
      >
        <div>
          <div 
            className={`${styles.iconWrapper} ${isActive === 1 ? styles.active : ''}`}
            onClick={() => setIsActive(1)}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="60" 
              height="60" 
              viewBox="0 0 24 24"
              className={styles.icon}
            >
              <path d="M16 2v2h3.586l-3.972 3.972c-1.54-1.231-3.489-1.972-5.614-1.972-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-2.125-.741-4.074-1.972-5.614l3.972-3.972v3.586h2v-7h-7zm-6 20c-3.86 0-7-3.14-7-7s3.14-7 7-7 7 3.14 7 7-3.14 7-7 7z"/>
            </svg>
          </div>

          <div 
            className={`${styles.iconWrapper} ${isActive === 2 ? styles.active : ''}`}
            onClick={() => setIsActive(2)}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="60" 
              height="60" 
              viewBox="0 0 90 90"
              className={styles.icon}
            >
              <path d="M 65.896 50.433 c 11.522 -11.522 11.522 -30.27 0 -41.792 c -11.521 -11.522 -30.27 -11.522 -41.792 0 c -11.522 11.522 -11.522 30.269 0 41.792 C 29.102 55.432 35.461 58.259 42 58.92 v 12.09 H 29.485 v 6.001 H 42 V 90 H 48 V 77.012 h 12.514 v -6.001 H 48 V 58.92 C 54.539 58.259 60.898 55.432 65.896 50.433 z M 28.347 12.885 C 32.939 8.294 38.969 5.998 45 5.998 c 6.031 0 12.061 2.295 16.653 6.886 c 9.182 9.183 9.182 24.123 0 33.306 c -9.183 9.182 -24.124 9.181 -33.305 0 C 19.165 37.008 19.165 22.067 28.347 12.885 z"/>
            </svg>
          </div>
        </div>
      </NotificationTemplate>
    </div>
  )
}

export default CreateCharacter