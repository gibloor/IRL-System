import ChoiceNotification from "@/components/Notifications/ChoiceNotification";
import NotificationTemplate from "@/components/Notifications/NotificationTemplate";
import RegularNotification from "@/components/Notifications/RegularNotification";
import Image from "next/image";
import styles from "./page.module.css";

export default function Home() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>

    </div>
  );
}
